1. I have used Eclipse to build this code having following details -
Version: Mars Release (4.5.0)
Build id: 20150621-1200

2. JDK version = jre1.8.0_60

3. Main method is in DupHT

4. Text file containing phone number is read by scanner.

