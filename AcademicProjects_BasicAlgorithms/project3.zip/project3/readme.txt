1. I have used Eclipse to build this code having following details -
Version: Mars Release (4.5.0)
Build id: 20150621-1200

2. All public methods in my code are on top

3. Main method is at the end 

4. JDK version = jre1.8.0_60

